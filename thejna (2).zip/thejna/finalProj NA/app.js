const express = require("express");
const mysql = require("mysql");
const doenv = require("dotenv");
const path = require("path");
const hbs = require("hbs");
const cookieParser = require("cookie-parser");
const multer = require('multer');


const app = express();

doenv.config({
  path: "./.env",
});
const db = mysql.createConnection({
  host: process.env.DATABASE_HOST,
  user: process.env.DATABASE_USER,
  password: process.env.DATABASE_PASS,
  database: process.env.DATABASE,
});

db.connect((err) => {
  if (err) {
    console.log(err);
  } else {
    console.log("MySQL Connection Success");
  }
});
app.use(cookieParser());
app.use(express.urlencoded({ extended: false }));

console.log(__dirname);
const location = path.join(__dirname, "./public");
app.use(express.static(location));
app.set("view engine", "hbs");

const partialsPath = path.join(__dirname, "./views/partials");
hbs.registerPartials(partialsPath);

app.use("/", require("./routes/pages"));
app.use("/auth", require("./routes/auth"));

const storage = multer.diskStorage({
  destination: './uploads', // Directory where files will be stored
  filename: function (req, file, cb) {
    // Rename the uploaded file if needed, e.g., to avoid naming conflicts
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({ storage });

app.post('/upload', upload.single("featureImage"), (req, res) => {
  // Access the uploaded file details via req.file
  const featureImage = req.file.filename; // Store the filename in the database

  // Process the file here (e.g., save the filename in the database)

  // Redirect to a success page
  res.redirect('/addpost');
});

/*app.post('/auth/addpost', (req, res) => {
  const formData = req.body; // Form data received from the POST request

  // Access form data from the request body
  const heading = req.body.heading;
  const category = req.body.category;
  const content = req.body.content;
//console.log("bj",heading);
  // You can do further processing here, such as storing the data in a database
  res.render('next', { heading });
  res.render('next', { category });
  res.render('next', { content });
  // Redirect to the next page
  //res.redirect('/next'); // Change '/next' to the actual URL of your next page
});*/

app.listen(5000, () => {
  console.log("Server Started @ Port 5000");
});